
package com.mycompany.metodos_de_gauus;

public class MetodoGaussSeidel {

    public static double[] gaussSeidel(double[][] m, double tol, int maxIter) {
        int n = m.length;
        double[] x = new double[n];
        double[] xOld = new double[n];

        for (int iter = 0; iter < maxIter; iter++) {
            System.arraycopy(x, 0, xOld, 0, n);
            for (int i = 0; i < n; i++) {
                double sum = m[i][n];
                for (int j = 0; j < n; j++) {
                    if (j != i)
                        sum -= m[i][j] * x[j];
                }
                x[i] = sum / m[i][i];
            }

            boolean convergente = true;
            for (int i = 0; i < n; i++) {
                if (Math.abs(x[i] - xOld[i]) > tol) {
                    convergente = false;
                    break;
                }
            }
            if (convergente) break;
        }
        return x;
    }

    // Procedimiento detallado
    public static String procedimientoGaussSeidel(double[][] m, double tol, int maxIter) {
        StringBuilder sb = new StringBuilder();
        int n = m.length;
        double[] x = new double[n];
        double[] xOld = new double[n];

        sb.append("Procedimiento paso a paso:\n");
        for (int i = 0; i < n; i++)
            sb.append(String.format("%.2fx1 + %.2fx2 + %.2fx3 = %.2f\n",
                    m[i][0], m[i][1], m[i][2], m[i][3]));
        sb.append("\n");

        for (int iter = 1; iter <= maxIter; iter++) {
            sb.append("Iteración ").append(iter).append(":\n");
            System.arraycopy(x, 0, xOld, 0, n);
            for (int i = 0; i < n; i++) {
                double sum = m[i][n];
                for (int j = 0; j < n; j++) {
                    if (j != i)
                        sum -= m[i][j] * x[j];
                }
                double xiOld = x[i];
                x[i] = sum / m[i][i];
                sb.append(String.format("x%d: %.4f -> %.4f\n", i + 1, xiOld, x[i]));
            }

            boolean convergente = true;
            for (int i = 0; i < n; i++) {
                if (Math.abs(x[i] - xOld[i]) > tol) {
                    convergente = false;
                    break;
                }
            }
            sb.append("\n");
            if (convergente) {
                sb.append("Convergencia alcanzada.\n");
                break;
            }
        }

        sb.append("Solución final:\n");
        for (int i = 0; i < n; i++)
            sb.append(String.format("x%d = %.4f\n", i + 1, x[i]));

        return sb.toString();
    }

    // Tabla de iteraciones para txtTabla
    public static String tablaGaussSeidel(double[][] m, double tol, int maxIter) {
    StringBuilder sb = new StringBuilder();
    int n = m.length;
    double[] x = new double[n];
    double[] xOld = new double[n];

    // Encabezado de la tabla con bordes
    sb.append("+------------I------------I------------I------------I------------I------------+\n");
    sb.append(String.format("|%-20s|%-10s|%-15s|%-15s|%-10s|%-10s|\n", "x1", "x2", "x3", "ε1", "ε2", "ε3"));
    sb.append("+------------I------------I------------I------------I------------I------------+\n");

    for (int iter = 1; iter <= maxIter; iter++) {
        System.arraycopy(x, 0, xOld, 0, n);
        double[] errores = new double[n];
        boolean cambioSignificativo = false;

        for (int i = 0; i < n; i++) {
            double sum = m[i][n];
            for (int j = 0; j < n; j++) {
                if (j != i) sum -= m[i][j] * x[j];
            }
            double xiOld = x[i];
            x[i] = sum / m[i][i];
            errores[i] = Math.abs(x[i] - xiOld);
            if (errores[i] > tol) cambioSignificativo = true;
        }

        sb.append(String.format("|%9.4f|%9.4f|%9.4f|%9.4f|%9.4f|%9.4f|\n",
                x[0], x[1], x[2], errores[0], errores[1], errores[2]));

        if (!cambioSignificativo) break;
    }

    sb.append("+------------I------------I------------I------------I------------I------------+\n");

    sb.append("\nSolución final:\n");
    for (int i = 0; i < n; i++)
        sb.append(String.format("x%d = %.4f\n", i + 1, x[i]));

    return sb.toString();
}}