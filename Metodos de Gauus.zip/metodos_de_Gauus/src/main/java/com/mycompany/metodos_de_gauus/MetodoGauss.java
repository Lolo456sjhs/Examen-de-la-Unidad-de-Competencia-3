
package com.mycompany.metodos_de_gauus;

public class MetodoGauss {

    public static double[] gauss(double[][] m) {
        double[][] matriz = new double[3][4];
        double[] x = new double[3];
        // Copiar matriz
        for(int i=0;i<3;i++)
            System.arraycopy(m[i], 0, matriz[i], 0, 4);

        // Eliminación hacia adelante
        for(int k=0;k<2;k++){
            for(int i=k+1;i<3;i++){
                double factor = matriz[i][k]/matriz[k][k];
                for(int j=k;j<4;j++)
                    matriz[i][j]-=factor*matriz[k][j];
            }
        }

        // Sustitución regresiva
        for(int i=2;i>=0;i--){
            x[i]=matriz[i][3];
            for(int j=i+1;j<3;j++)
                x[i]-=matriz[i][j]*x[j];
            x[i]/=matriz[i][i];
        }
        return x;
    }

    public static String procedimientoGauss(double[][] m) {
        StringBuilder sb = new StringBuilder();
        double[][] matriz = new double[3][4];
        for(int i=0;i<3;i++)
            System.arraycopy(m[i], 0, matriz[i], 0, 4);

        sb.append("Ecuación original:\n");
        for(int i=0;i<3;i++)
            sb.append(String.format("%.2fx + %.2fy + %.2fz = %.2f\n",
                    matriz[i][0], matriz[i][1], matriz[i][2], matriz[i][3]));

        for(int k=0;k<2;k++){
            sb.append("\nPaso ").append(k+1).append(" de eliminación:\n");
            for(int i=k+1;i<3;i++){
                double factor = matriz[i][k]/matriz[k][k];
                sb.append(String.format("Fila %d - %.2f*Fila %d\n", i+1, factor, k+1));
                for(int j=k;j<4;j++)
                    matriz[i][j]-=factor*matriz[k][j];
                sb.append("Fila ").append(i+1).append(": ");
                for(int j=0;j<4;j++)
                    sb.append(String.format("%.2f ", matriz[i][j]));
                sb.append("\n");
            }
        }

        double[] x = new double[3];
        sb.append("\nSustitución regresiva:\n");
        for(int i=2;i>=0;i--){
            x[i]=matriz[i][3];
            for(int j=i+1;j<3;j++)
                x[i]-=matriz[i][j]*x[j];
            x[i]/=matriz[i][i];
            sb.append(String.format("x%d = %.2f\n", i+1, x[i]));
        }

        sb.append("\nSolución final:\n");
        for(int i=0;i<3;i++)
            sb.append(String.format("x%d = %.2f\n", i+1, x[i]));

        return sb.toString();
    }
    public static String tablaGauss(double[][] matriz) {
    StringBuilder sb = new StringBuilder();
    sb.append("Matriz inicial:\n");
    sb.append(formatearMatriz(matriz));
    sb.append("\n");

    int n = matriz.length;

    for (int i = 0; i < n; i++) {
        // Dividir la fila i por el pivote
        double pivote = matriz[i][i];
        if (pivote == 0) {
            sb.append("Pivote cero en fila ").append(i + 1).append("\n");
            continue;
        }
        for (int j = i; j < matriz[i].length; j++) {
            matriz[i][j] /= pivote;
        }
        sb.append("a[").append(i + 1).append("][j] = a[").append(i + 1).append("][j]/a[").append(i + 1).append("][")
                .append(i + 1).append("]\n");
        sb.append(formatearMatriz(matriz)).append("\n");

        // Hacer ceros en las demás filas
        for (int k = 0; k < n; k++) {
            if (k != i) {
                double factor = matriz[k][i];
                for (int j = i; j < matriz[k].length; j++) {
                    matriz[k][j] -= factor * matriz[i][j];
                }
                sb.append("a[").append(k + 1).append("][j] = a[").append(k + 1).append("][j] - a[").append(k + 1)
                        .append("][").append(i + 1).append("]*a[").append(i + 1).append("][j]\n");
                sb.append(formatearMatriz(matriz)).append("\n");
            }
        }
    }

    sb.append("Solución:\n");
    for (int i = 0; i < n; i++) {
        sb.append("x").append(i + 1).append(" = ").append(matriz[i][matriz[i].length - 1]).append("\n");
    }

    return sb.toString();
}

// Método auxiliar para formatear la matriz con columnas alineadas
private static String formatearMatriz(double[][] matriz) {
    StringBuilder sb = new StringBuilder();
    for (double[] fila : matriz) {
        for (double val : fila) {
            sb.append(String.format("%10.4f", val));
        }
        sb.append("\n");
    }
    return sb.toString();
}}