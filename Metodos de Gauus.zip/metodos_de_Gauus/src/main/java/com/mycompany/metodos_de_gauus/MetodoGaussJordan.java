
package com.mycompany.metodos_de_gauus;

public class MetodoGaussJordan {

    public static double[] gaussJordan(double[][] m) {
        double[][] matriz = new double[3][4];
        double[] x = new double[3];

        // Copiar la matriz original
        for (int i = 0; i < 3; i++)
            System.arraycopy(m[i], 0, matriz[i], 0, 4);

        // Proceso de Gauss-Jordan
        for (int i = 0; i < 3; i++) {
            // Hacer pivote 1
            double pivote = matriz[i][i];
            for (int j = 0; j < 4; j++)
                matriz[i][j] /= pivote;

            // Eliminar otros elementos de la columna
            for (int k = 0; k < 3; k++) {
                if (k != i) {
                    double factor = matriz[k][i];
                    for (int j = 0; j < 4; j++)
                        matriz[k][j] -= factor * matriz[i][j];
                }
            }
        }

        // Extraer soluciones
        for (int i = 0; i < 3; i++)
            x[i] = matriz[i][3];

        return x;
    }

    public static String procedimientoGaussJordan(double[][] m) {
        StringBuilder sb = new StringBuilder();
        double[][] matriz = new double[3][4];

        // Copiar matriz
        for (int i = 0; i < 3; i++)
            System.arraycopy(m[i], 0, matriz[i], 0, 4);

        sb.append("Matriz original:\n");
        for (int i = 0; i < 3; i++)
            sb.append(String.format("%.2f\t%.2f\t%.2f\t%.2f\n", matriz[i][0], matriz[i][1], matriz[i][2], matriz[i][3]));

        for (int i = 0; i < 3; i++) {
            sb.append("\nPaso ").append(i + 1).append(" - Pivote en fila ").append(i + 1).append(":\n");

            // Hacer pivote 1
            double pivote = matriz[i][i];
            sb.append(String.format("Dividir fila %d entre %.2f\n", i + 1, pivote));
            for (int j = 0; j < 4; j++)
                matriz[i][j] /= pivote;

            sb.append("Fila ").append(i + 1).append(": ");
            for (int j = 0; j < 4; j++)
                sb.append(String.format("%.2f\t", matriz[i][j]));
            sb.append("\n");

            // Eliminar otros elementos de la columna
            for (int k = 0; k < 3; k++) {
                if (k != i) {
                    double factor = matriz[k][i];
                    sb.append(String.format("Fila %d - %.2f*Fila %d\n", k + 1, factor, i + 1));
                    for (int j = 0; j < 4; j++)
                        matriz[k][j] -= factor * matriz[i][j];

                    sb.append("Fila ").append(k + 1).append(": ");
                    for (int j = 0; j < 4; j++)
                        sb.append(String.format("%.2f\t", matriz[k][j]));
                    sb.append("\n");
                }
            }
        }

        sb.append("\nSolución final:\n");
        for (int i = 0; i < 3; i++)
            sb.append(String.format("x%d = %.2f\n", i + 1, matriz[i][3]));

        return sb.toString();
    }
    public static String tablaGaussJordan(double[][] m) {
    StringBuilder sb = new StringBuilder();
    int n = m.length;
    double[][] a = new double[n][n+1];

    // Copiar la matriz original
    for (int i = 0; i < n; i++)
        System.arraycopy(m[i], 0, a[i], 0, n+1);

    sb.append("Matriz inicial:\n");
    sb.append(formatearMatriz(a));

    for (int k = 0; k < n; k++) {
        double pivote = a[k][k];

        // Dividir fila pivote
        for (int j = 0; j < n+1; j++)
            a[k][j] /= pivote;
        sb.append("Dividir fila ").append(k+1).append(" por el pivote a[").append(k+1).append("][").append(k+1).append("]\n");
        sb.append(formatearMatriz(a));

        // Eliminar otras filas
        for (int i = 0; i < n; i++) {
            if (i != k) {
                double factor = a[i][k];
                for (int j = 0; j < n+1; j++)
                    a[i][j] -= factor * a[k][j];
                sb.append("Fila ").append(i+1).append(" = F").append(i+1).append(" - ").append(factor)
                        .append("*F").append(k+1).append("\n");
                sb.append(formatearMatriz(a));
            }
        }
    }

    sb.append("La solución es:\n");
    for (int i = 0; i < n; i++)
        sb.append(String.format("x%d = %.4f\n", i + 1, a[i][n]));

    return sb.toString();
}

// Método auxiliar para imprimir la matriz alineada
private static String formatearMatriz(double[][] matriz) {
    StringBuilder sb = new StringBuilder();
    for (double[] fila : matriz) {
        for (double val : fila)
            sb.append(String.format("%10.4f", val));
        sb.append("\n");
    }
    return sb.toString();
}}